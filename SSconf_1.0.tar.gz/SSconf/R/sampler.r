#' Gibbs Sampler Algorithm
#'
#' @description
#' This function executes the Gibbs sampler as described in the paper.
#'
#' @note The input variables must be unscaled, as the standardization is performed within this function.
#'
#' @param y Either a formula or a vector corresponding to the response variable.
#' @param x Either a data-frame (containing also \code{y} if it is a formula) or matrix corresponding to the 
#' \emph{p} covariates that are always selected. The first column can be the intercept
#' (in which case the columns are \emph{p+1}). Factor columns are NOT scaled.
#' @param B A matrix corresponding to the basis functions that will be selected using spike&slab prior
#' on related coefficients. The matrix must NOT include the intercept.
#' @param init A named list containing the starting values for the parameters. If not provided,
#' starting values are chosen at random. See details below.
#' @param numBlocks An integer indicating into how many blocks the coefficient vector must
#' be partitioned during the Gibbs sampler updates. This is useful to speed-up computations.
#' @param priors A named list containing the hyperparameters of the model. See details below.
#' @param SS_priortype An integer indicating the type of spike & slab priors to use. The value is 1
#' for the continuous spike & slab priors by George & McCulloch (1997), or 2 for Normal Mixture of Inverse
#' Gamma (NMIG) priors.
#' @param iters Number of iterations to keep after burn-in.
#' @param burnin Number of iterations to discard.
#' @param thinning An integer indicating the thinning value. Default is 1.
#' @param w_indifference logical. If TRUE (default) the probability parameter of the binomial indicator
#' variable (i.e, 'w' in the paper) is fixed at 0.5. If FALSE, a Beta prior is assumed on this parameter
#' with hyperparameters that must be defined in \code{priors}.
#' @param verbose logical. If TRUE (default), prints a progress bar.
#' @param restore_work logical. Default is FALSE. If TRUE the last execution is restored and continued, provided that the
#' number of burn-in and/or good iterations is greater. Previous works with \code{thinning>1}
#' cannot be restored.
#' 
#' @details \code{priors} must be a named list with these elements:
#' \describe{
#'  \item{beta}{A numeric vector of the type \code{c(mu, V)}. This defines the prior structure
#'  of the coefficients, \eqn{\beta}, related to the covariates in \code{x}. Each one is normally distributed
#'  with mean \code{mu} and variance \code{V}).}
#'  \item{sigma2y}{A numeric vector of the type \code{c(a, b)}. The error variance follows an Inverse-Gamma
#'  distribution with parameters \code{a} and \code{b}.}
#'  \item{spikeslab}{A numeric vector of the type \code{c(c_0, c_1)}, which correspond to the prior variance
#'  assigned to spike components or slab components, respectively.}
#'  \item{w}{(Optional) A numeric vector of the type \code{c(a, b)}. The parameter 'w' follows a Beta
#'  distribution with parameters \code{a} and \code{b}.}
#'  \item{psi}{A numeric vector of the type \code{c(a, b)}. The prior variance follows an
#'  Inverse-Gamma distribution with parameters \code{a} and \code{b}, under NMIG priors, otherwise it is
#'  fixed at 1.}  
#' }
#' 
#' \code{init} must be a named list with these elements:
#' \describe{
#'  \item{beta}{A numeric vector of dimension \emph{p} or \emph{p+1}, related to the coefficients \eqn{\beta}.}
#'  \item{sigma2y}{A scalar related to the error variance.}
#' }
#' 
#' @return A named list with the following elements:
##' \describe{
##'  \item{Postmean.beta}{A \emph{p} by 1 matrix corresponding to the posterior means of the coefficients \eqn{\beta},
##'  related to \code{x} without the intercept.}
##'  \item{Postmean.sigma2y}{The posterior mean of the variance of the error term.}
##'  \item{Beta.draws}{An (\code{iters/thinning}) by \emph{p} matrix where each column corresponds to the
##'  chain obtained after burn-in period for each element of \eqn{\beta}.}
##'  \item{sigma2y.draws}{The chain for the variance of the error term.}
##'  \item{xi.draws}{An (\code{iters/thinning}) by \code{ncol(B)} matrix where each column corresponds to the
##'  chain obtained after burn-in period for each basis coefficient.}
##'  \item{psi.draws}{An (\code{iters/thinning}) by \code{ncol(B)} matrix where each column corresponds to the
##'  chain obtained after burn-in period for the prior variance of each basis coefficient, when NMIG priors are chosen.}
##'  \item{Is_slab_matrix}{An (\code{iters/thinning}) by \code{ncol(B)} matrix where each entry is either 0 (spike) or 1 (slab).}
##'  \item{intercept_history}{The chain for the intercept coefficient.}
##'  \item{w.draws}{The chain for the parameter 'w'.}
##' }
#' @references insert here.
#' @export
#'
spsl = function(y, x, B, init = NULL, numBlocks, priors, SS_priortype, iters, burnin, thinning,
                w_indifference = T, verbose = T, restore_work = F) {
  stopifnot("'x' must be a matrix or data.frame, not a vector" = dim(x)!=NULL)
  cl = mf = match.call()
  xn = NULL
  if(purrr::is_formula(y)) {
    m <- match(c("y", "x"), names(mf), 0L)
    names(mf)[m] = c("formula", "data")
    mf <- mf[c(1L, m)]
    mf$drop.unused.levels <- TRUE
    mf[[1L]] <- quote(stats::model.frame)
    mf <- eval(mf, parent.frame())
    mt <- attr(mf, "terms")
    y <- model.response(mf, "numeric")
    XM <- model.matrix(mt, mf)
  } else {
    stopifnot("'y' is not a formula. It must be a vector" = is.numeric(y))
    if (is.data.frame(x)) {
      hasfct = sapply(x, function(column) is.factor(column))
      if (sum(hasfct)>0) cat("Note: Factors in 'x' are converted to numeric. If any of them has more than two levels, the formula must be used instead.\n")
      XM = data.matrix(type.convert(x, as.is = TRUE))
    }
    if (is.matrix(x)) XM = x
  }
  isfct = unname(apply(XM, 2, function(column) as.numeric(length(unique(column))==2)))
  xn = if (length(unique(XM[,1]))==1) colnames(XM)[-1] else colnames(XM)
  B = as.matrix(B)

  if (is.null(init)) {
    init = list()
    init$beta = rnorm(ncol(XM))
    init$xi = rnorm(ncol(B))
    init$sigma2y = 1/rgamma(1, priors$sigma2y[1],priors$sigma2y[2])
  } else {init$xi = rnorm(ncol(B))}
  if (!w_indifference & !("w" %in% names(priors))) priors$w = c(1, 1)
  stopifnot(c("beta", "xi", "sigma2y") %in% names(init))
  stopifnot(c("beta", "sigma2y", "w", "spikeslab", "psi") %in% names(priors))

  ans = spsl2(y, XM, B, init$beta, init$xi, init$sigma2y, numBlocks, isfct, priors, SS_priortype,
              iters, burnin, thinning, w_indifference, "gaussian", verbose, restore_work)
  ans$call = cl
  colnames(ans$Postmean.beta) = colnames(ans$Beta.draws) = xn
  return(ans)
}
