// [[Rcpp::depends(RcppArmadillo, RcppProgress, RcppDist)]]
// [[Rcpp::plugins("cpp11")]]
#include <RcppArmadillo.h>
#include <math.h>
#include <string.h>
#include <progress.hpp>
#include <progress_bar.hpp>
#include <truncnorm.h>
#include "gibbsupdate.h"
using namespace Rcpp;
using namespace gibbsupdate;





arma::mat scale(const arma::mat& X){ //equivalent to scale() in R
	arma::mat m = arma::mean(X);
	arma::mat M = repmat(m, X.n_rows, 1);
	arma::rowvec s = arma::stddev(X);
	arma::mat S = repmat(s, X.n_rows, 1);
	arma::mat out = (X-M)/S;
	return out;
}

arma::vec rbinom2(int n, double size, arma::vec prob) { 
    arma::vec v(n, arma::fill::none);
	for(int i=0; i<n; ++i) {
		v(i) = R::rbinom(size, prob(i));
	}
    return v;
}

arma::vec rgamma2(int n, double a, arma::vec scale) { 
    arma::vec v(n, arma::fill::none);
	for(int i=0; i<n; ++i) {
		v(i) = R::rgamma(a, scale(i));
	}
    return v;
}

arma::vec dnorm2(arma::vec x, double mean, arma::vec sd, bool log = false) {
    int n = x.n_elem;
    arma::vec v(n, arma::fill::ones);
	if (sd.n_elem==1) sd = v*sd;
	for(int i=0; i<n; ++i){
		v(i) = R::dnorm(x(i), mean, sd(i), log);
	}
    return v;
}

arma::vec rtrunorm(const int n, const arma::vec mu, const double sigma, const double a, const double b) { 
    arma::vec v(n, arma::fill::none);
	for(int i=0; i<n; ++i) {
		v(i) = r_truncnorm(mu(i), sigma, a, b);
	}
    return v;
}


List spikenslab(const double& s_0, const double& s_1, const bool& w_indifference, const double& a_w, const double& b_w, const double& num_prev_slabs,
				const double& num_prev_spikes, const double& a_p, const double& b_p, const arma::vec& lambda, const arma::vec& psi2, const int& priortype) {
	//NumericVector lambda_draw = as<NumericVector>(wrap(lambda));
	arma::vec psi2_draw = psi2;
	double w, a, b;
	if (w_indifference) {
		w = 0.5;
	} else {
		a = a_w + num_prev_slabs;
		b = b_w + num_prev_spikes;
		w = R::rbeta(a, b);
	}
	int len = lambda.n_elem;
	arma::vec ny(len, arma::fill::none);
	arma::vec Var_spike_slab = ny;
	arma::vec nyb = ny;
	
	int num_spikes, num_slabs;
	arma::vec u_ij0, u_ij1, ost0, ost1;
	//IntegerVector ll; // arma::uvec ll;
	arma::vec ss1 = {s_1}, ss0 = {s_0};
	switch(priortype) {
		case 1: // George and McCulloch priors
		{
			u_ij1 = w * dnorm2(lambda, 0.0, arma::sqrt(ss1));
			u_ij0 = (1.0-w) * dnorm2(lambda, 0.0, arma::sqrt(ss0));
			ost1 = u_ij1 / (u_ij1 + u_ij0);
			ost1.replace(arma::datum::nan, 1.0);
			nyb = rbinom2(len, 1, ost1);
			Var_spike_slab = (1.0-nyb)*s_0 + nyb*s_1;
			num_slabs = arma::sum(nyb); //num_spikes = ll.n_elem;
			num_spikes = len - num_slabs; //num_slabs = len - num_spikes;
			break;
		}
		case 2: // NMIG priors
		{
			u_ij1 = w * dnorm2(lambda, 0.0, arma::sqrt(psi2_draw*ss1));
			u_ij0 = (1.0-w) * dnorm2(lambda, 0.0, arma::sqrt(psi2_draw*ss0));
			ost1 = u_ij1 / (u_ij1 + u_ij0);
			ost1.replace(arma::datum::nan, 1.0);
			nyb = rbinom2(len, 1, ost1);
			ny = (1.0-nyb)*s_0 + nyb*s_1;
			psi2_draw = 1.0/rgamma2(len, a_p + 0.5, 1.0/(b_p + arma::pow(lambda, 2.0)/(2.0*ny)));
			Var_spike_slab = ((1.0-nyb)*s_0)%psi2_draw + (nyb*s_1)%psi2_draw;
			num_slabs = arma::sum(nyb); //num_spikes = ll.n_elem;
			num_spikes = len - num_slabs; //num_slabs = len - num_spikes;
			break;
		}
		default:
			stop("Object 'priortype' must be: 1 (George-McCulloch) or 2 (NMIG)");
			break;
	}
	
	return List::create(Named("Var_spike_slab") = Var_spike_slab,
						Named("Is_slab") = nyb,
						Named("num.spikes") = num_spikes,
						Named("num.slabs") = num_slabs,
						Named("psi2_draw") = psi2_draw,
						Named("w") = w);
	
}


int modulo(int a, int b) {return a - std::floor(a / b) * b;}


// [[Rcpp::export]]
List simple_lm(const arma::vec& initial_beta, const int& numBlocks,
							const double& initial_sigma2y,
							const List& priors, const arma::vec& y, const arma::mat& x,
							const int& iters, const int& burnin, const int& priortype,
							const bool& report = true) {
	int n = y.n_elem;
	int lbx = x.n_cols;	
	
	NumericVector pb = priors["beta"];
	//arma::vec pbm(lbx, arma::fill::none); pbm.arma::fill(pb(0));
	arma::vec pbV(lbx, arma::fill::none); pbV.fill(pb(1));
	arma::mat invV = arma::diagmat(arma::pow(pbV, -1.0));
	
	arma::vec alldraw = initial_beta;
	
	double s2ydraw = initial_sigma2y;
	
	arma::mat beta_history(iters, lbx, arma::fill::none);
	arma::vec sigma2y_history(iters, arma::fill::none);
	NumericVector pis = priors["sigma2y"];
	
	int start = 0;
	int totaliters = iters + burnin;
	Progress pr(totaliters, report);	
	
	arma::vec ones(iters, arma::fill::ones);
	for(int i = start; i<totaliters; ++i){
		pr.increment(); // update progress
		
		// alldraw
		alldraw = beta_gibbs0(y, x, alldraw, invV, arma::eye(n,n), s2ydraw, priortype, numBlocks);
		// sigmay^2
		s2ydraw = sigma2_gibbs(y, x, alldraw, invV, arma::eye(n,n), pis, priortype);
		
		if (i >= burnin) {
			beta_history.row(i-burnin) = alldraw.t();
			sigma2y_history.row(i-burnin) = s2ydraw;
		}
	}
	
	
	
	
	arma::mat pmeanbeta;
	if (lbx>0) {
	  pmeanbeta = arma::mean(beta_history);
	}
	
	return List::create(Named("Postmean.beta") = pmeanbeta,
						Named("Postmean.sigmay") = arma::mean(sigma2y_history),
						Named("Beta.draws") = beta_history,
						Named("sigmay.draws") = sigma2y_history);
}




/*
// [[Rcpp::export]]
List spsl_bin(const arma::vec& y, arma::mat& x, const arma::mat& B, arma::vec initial_beta, const arma::vec& initial_xi, const double& initial_sigma2y,
			const int& numBlocks, const List& priors, const int& SS_priortype, const int& iters, const int& burnin, const int& thinning = 1,
			const bool& w_indifference = true, const bool& verbose = true, const bool& restore_work = false) {
	if (restore_work & (thinning>1)) { stop("Cannot restore previous work if thinning is not 1"); }
	Environment base("package:base");
	Function readRDS = base["readRDS"];
	Function saveRDS = base["saveRDS"];
	std::string filename = "Last_spsl.RDS";
	int p = initial_xi.n_elem, lbx = initial_beta.n_elem;
	int n = x.n_rows, xnc = x.n_cols, Bnc = B.n_cols;
	if(Bnc != p || xnc != lbx) {
		stop("Check dimensions of input arguments");
	}
	// standardize data and remove intercept if present in 'x'
	// scaled intercept produces 'nan'
	arma::mat xst = scale(x);
	if (xst.has_nan()) {
		arma::uvec indna = find_nonfinite(xst.row(0));
		x.shed_cols(indna);
		xst.shed_cols(indna);
		lbx = lbx - indna.n_elem;
		initial_beta.shed_rows(indna);
	}
	arma::vec ystar(n, arma::fill::randn);
	
	
	
	
	
	
	
	
	arma::mat Bst = scale(B);
	arma::mat desst = join_rows(xst, Bst); //cbind()
	arma::mat design = join_rows(x, B);
	double sdy = arma::stddev(y);
	double vary = arma::var(y);
	arma::rowvec sdx = arma::stddev(x);
	arma::vec sddes = arma::stddev(design).t();
	arma::mat onesn(n, 1, arma::fill::ones);
	
	NumericVector pb = priors["beta"];
	arma::vec pbm(lbx, arma::fill::none); pbm.arma::fill(pb(0));
	arma::vec pbV(lbx, arma::fill::none); pbV.arma::fill(pb(1));	
	//arma::vec priormean(lbx+p, arma::fill::zeros);
	arma::vec priorV(lbx+p, arma::fill::none);
	//priormean.subvec(0, lbx-1) = pbm;
	priorV.subvec(0, lbx-1) = pbV;
	
	NumericVector pss = priors["spikeslab"];
	double s_0 = pss(0); // variance of the spike
	double s_1 = pss(1); // variance of the slab
	
	arma::vec alldraw = join_cols(initial_beta, initial_xi);
	alldraw = alldraw % sddes / sdy;
	double s2ydraw = initial_sigma2y / vary;
	arma::vec intc(1, arma::fill::zeros);
	
	// matrices to store results
	arma::mat beta_history(std::floor(iters/thinning), lbx, arma::fill::none);
	arma::mat xi_history(std::floor(iters/thinning), p, arma::fill::none);
	arma::vec sigma2y_history(std::floor(iters/thinning), arma::fill::none);
	arma::mat Is_slab_matrix(std::floor(iters/thinning), p, arma::fill::none);
	arma::mat psi2_history(std::floor(iters/thinning), p, arma::fill::none);
	arma::vec w_history(std::floor(iters/thinning), arma::fill::none);
	arma::vec intc_history(std::floor(iters/thinning), arma::fill::none);
	
	double num_prev_slabs = floor(p/2), num_prev_spikes = p - num_prev_slabs;

	NumericVector pis = priors["sigma2y"];
	NumericVector pw = priors["w"];
	double a_w = pw(0), b_w = pw(1);
	NumericVector ppsi = priors["psi"];
	double a_p = ppsi(0), b_p = ppsi(1);
	arma::vec psi2draw(p, arma::fill::ones);
	
	int beta_priortype = 2;
	
	int start = 0;
	int totaliters = iters + burnin;
	Progress pr(totaliters, verbose);
	
	List last_work = List::create(13);
	
	if(restore_work) {
		last_work = readRDS(Named("file", filename));
	  
		int lwburnin = last_work["burnin"];
		if(lwburnin > burnin) {
			stop("Provide a burnin >= previous work's burnin");
		}
		
		int lwiters = last_work["iters"];
		int last_total = lwburnin + lwiters;
		int diff_burnin = burnin - lwburnin;
		if(last_total >= totaliters) {
			stop("New total iterations must be > than previous one");
		}
		
		if(last_total > burnin) {
			arma::mat lwbetah = last_work["beta_history"];
			beta_history.rows(0, last_total-burnin-1) = lwbetah.rows(diff_burnin, lwiters-1);
			arma::mat lwdeltah = last_work["xi_history"];
			xi_history.rows(0, last_total-burnin-1) = lwdeltah.rows(diff_burnin, lwiters-1);
			arma::mat lwsigmah = last_work["sigma2y_history"];
			sigma2y_history.rows(0, last_total-burnin-1) = lwsigmah.rows(diff_burnin, lwiters-1);
			arma::mat lwslabm = last_work["Is_slab_matrix"];
			Is_slab_matrix.rows(0, last_total-burnin-1) = lwslabm.rows(diff_burnin, lwiters-1);
			arma::mat lwwh = last_work["w_history"];
			w_history.rows(0, last_total-burnin-1) = lwwh.rows(diff_burnin, lwiters-1);
			arma::mat lwih = last_work["intc_history"];
			intc_history.rows(0, last_total-burnin-1) = lwih.rows(diff_burnin, lwiters-1);
			arma::mat lwpsih = last_work["psi2_history"];
			psi2_history.rows(0, last_total-burnin-1) = lwpsih.rows(diff_burnin, lwiters-1);
		}
		alldraw = as<arma::vec>(last_work["alldraw"]);
		intc = as<arma::vec>(last_work["intc"]);
		num_prev_slabs = last_work["num_prev_slabs"];
		num_prev_spikes = last_work["num_prev_spikes"];
		start = last_total;
	}
	
	// start sampler
	for(int i = start; i<totaliters; ++i){
		pr.increment(); // update progress
		
		// spike & slab
		List temp = spikenslab(s_0, s_1, w_indifference, a_w, b_w, num_prev_slabs, num_prev_spikes, a_p, b_p, alldraw.subvec(lbx, alldraw.n_elem-1), psi2draw, SS_priortype);
		arma::vec dMat = temp["Var_spike_slab"];
		priorV.subvec(lbx, priorV.n_elem-1) =  dMat;
		arma::mat invV = arma::diagmat(arma::pow(priorV, -1));
		num_prev_slabs = temp["num.slabs"];
		num_prev_spikes = temp["num.spikes"];
		psi2draw = as<arma::arma::vec>(temp["psi2_draw"]);
		
		// sigmay^2 and alldraw
		s2ydraw = sigma2_gibbs(yst, desst, alldraw, invV, arma::eye(n,n), pis, beta_priortype);
		alldraw = beta_gibbs0(yst, desst, alldraw, invV, arma::eye(n,n), s2ydraw, beta_priortype, numBlocks);
		
		// intercept
		intc = beta_gibbs0(y - design * (alldraw % (sdy/sddes)), onesn, intc, invV.submat(0,0,0,0)*0+1e-6, arma::eye(n,n), s2ydraw*vary, beta_priortype, 1);
		
		arma::vec isslab = temp["Is_slab"];
		
		// save draws
		int temp00 = modulo(i, thinning);
		if ((i >= burnin) & (temp00==0)) {
			if (lbx>0){ beta_history.row((i-burnin)/thinning) = arma::trans(alldraw.subvec(0, lbx-1)); }
			xi_history.row((i-burnin)/thinning) = arma::trans(alldraw.subvec(lbx, alldraw.n_elem-1));
			sigma2y_history.row((i-burnin)/thinning) = s2ydraw;
			Is_slab_matrix.row((i-burnin)/thinning) = isslab.t();
			psi2_history.row((i-burnin)/thinning) = psi2draw.t();
			double tempw = temp["w"];
			w_history.row((i-burnin)/thinning) = tempw;
			intc_history.row((i-burnin)/thinning) = intc;
		}
	}
	
	last_work["alldraw"] = alldraw;
	last_work["intc"] = intc;
	last_work["beta_history"] = beta_history;
	last_work["sigma2y_history"] = sigma2y_history;
	last_work["xi_history"] = xi_history;
	last_work["psi2_history"] = psi2_history;
	last_work["Is_slab_matrix"] = Is_slab_matrix;
	last_work["w_history"] = w_history;
	last_work["intc_history"] = intc_history;
	last_work["iters"] = beta_history.n_rows;
	last_work["burnin"] = totaliters - beta_history.n_rows;
	last_work["num_prev_slabs"] = num_prev_slabs;
	last_work["num_prev_spikes"] = num_prev_spikes;
	
	saveRDS(last_work, wrap(filename));
	
	// results back to original scale
	arma::vec ones(std::floor(iters/thinning), arma::fill::ones);
	if (lbx>0) {
	  beta_history = beta_history * sdy / (ones * sdx);
	}
	sigma2y_history = sigma2y_history * vary;
	xi_history = xi_history * sdy / (ones * arma::stddev(B));
	psi2_history = psi2_history * vary / (ones * arma::var(B));
	
	arma::mat pmeanbeta;
	if (lbx>0) {
	  pmeanbeta = arma::mean(beta_history);
	}
	
	return List::create(Named("Postmean.beta") = pmeanbeta,
						Named("Postmean.sigma2y") = arma::mean(sigma2y_history),
						Named("Beta.draws") = beta_history,
						Named("sigma2y.draws") = sigma2y_history,
						Named("xi.draws") = xi_history,
						Named("psi.draws") = psi2_history,
						Named("Is_slab_matrix") = Is_slab_matrix,
						Named("intercept_history") = intc_history,
						Named("w.draws") = w_history);
}
*/

// [[Rcpp::export]]
List spsl2(const arma::vec& y, arma::mat& x, const arma::mat& B, arma::vec initial_beta, const arma::vec& initial_xi, const double& initial_sigma2y,
			const int& numBlocks, arma::vec isfactor, const List& priors, const int& SS_priortype, const int& iters, const int& burnin, const int& thinning = 1,
			const bool& w_indifference = true, const std::string& family = "gaussian", const bool& verbose = true, const bool& restore_work = false) {
	if (restore_work & (thinning>1)) { stop("Cannot restore previous work if thinning is not 1"); }
	Environment base("package:base");
	Function readRDS = base["readRDS"];
	Function saveRDS = base["saveRDS"];
	std::string filename = "Last_spsl.RDS";
	int p = initial_xi.n_elem, lbx = initial_beta.n_elem;
	int n = x.n_rows, xnc = x.n_cols, Bnc = B.n_cols;
	if(Bnc != p || xnc != lbx) {
		stop("Check dimensions of input arguments");
	}
	// standardize data and remove intercept if present in 'x'
	// scaled intercept produces 'nan'
	arma::mat xst = scale(x);
	arma::uvec indna;
	if (xst.has_nan()) {
		indna = find_nonfinite(xst.row(0));
		x.shed_cols(indna);
		xst.shed_cols(indna);
		lbx = lbx - indna.n_elem;
		initial_beta.shed_rows(indna);
		isfactor.shed_rows(indna);
	}
	arma::uvec indfac = find(isfactor==1.0);
	xst.cols(indfac) = x.cols(indfac);
	arma::vec yst = scale(y);
	arma::mat Bst = scale(B);
	arma::mat desst = join_rows(xst, Bst); //cbind()
	arma::mat design = join_rows(x, B);
	double sdy = arma::stddev(y);
	double vary = arma::var(y);
	arma::rowvec sdx = arma::stddev(x);
	sdx.elem(indfac).ones();
	arma::vec sddes = arma::stddev(design).t();
	sddes.elem(indfac).ones();
	arma::mat onesn(n, 1, arma::fill::ones);
	
	arma::vec latent(n, arma::fill::randn); // binomial: latent variable
	arma::vec prob1(n, arma::fill::zeros); // binomial: P(Y=1)
	arma::uvec ids1, ids0;
	double s2ydraw;//, n0 = 0.0, n1 = 0.0;
	if (family=="gaussian") {
		latent = yst;
		s2ydraw = initial_sigma2y;
	} else {
		s2ydraw = 1.0;
		ids1 = find(y == 1.0);
		ids0 = find(y == 0.0);
		//n0 = ids0.n_elem, n1 = ids1.n_elem;
	}
	
	NumericVector pb = priors["beta"];
	arma::vec pbm(lbx, arma::fill::none); pbm.fill(pb(0));
	arma::vec pbV(lbx, arma::fill::none); pbV.fill(pb(1));	
	//arma::vec priormean(lbx+p, arma::fill::zeros);
	arma::vec priorV(lbx+p, arma::fill::none);
	//priormean.subvec(0, lbx-1) = pbm;
	priorV.subvec(0, lbx-1) = pbV;
	
	NumericVector pss = priors["spikeslab"];
	double s_0 = pss(0); // variance of the spike
	double s_1 = pss(1); // variance of the slab
	
	arma::vec alldraw = join_cols(initial_beta, initial_xi);
	alldraw = alldraw % sddes / sdy;
	s2ydraw = s2ydraw / vary;
	arma::vec intc(1, arma::fill::zeros);
	
	// matrices to store results
	arma::mat beta_history(std::floor(iters/thinning), lbx, arma::fill::none);
	arma::mat xi_history(std::floor(iters/thinning), p, arma::fill::none);
	arma::vec sigma2y_history(std::floor(iters/thinning), arma::fill::none);
	arma::mat Is_slab_matrix(std::floor(iters/thinning), p, arma::fill::none);
	arma::mat psi2_history(std::floor(iters/thinning), p, arma::fill::none);
	arma::vec w_history(std::floor(iters/thinning), arma::fill::none);
	arma::vec intc_history(std::floor(iters/thinning), arma::fill::none);
	
	double num_prev_slabs = std::floor(p/2), num_prev_spikes = p - num_prev_slabs;

	NumericVector pis = priors["sigma2y"];
	NumericVector pw = priors["w"];
	double a_w = pw(0), b_w = pw(1);
	NumericVector ppsi = priors["psi"];
	double a_p = ppsi(0), b_p = ppsi(1);
	arma::vec psi2draw(p, arma::fill::ones);
	
	int beta_priortype = 2;
	
	int start = 0;
	int totaliters = iters + burnin;
	Progress pr(totaliters, verbose);
	
	List last_work = List::create(13);
	
	if(restore_work) {
		last_work = readRDS(Named("file", filename));
	  
		int lwburnin = last_work["burnin"];
		if(lwburnin > burnin) {
			stop("Provide a burnin >= previous work's burnin");
		}
		
		int lwiters = last_work["iters"];
		int last_total = lwburnin + lwiters;
		int diff_burnin = burnin - lwburnin;
		if(last_total >= totaliters) {
			stop("New total iterations must be > than previous one");
		}
		
		if(last_total > burnin) {
			arma::mat lwbetah = last_work["beta_history"];
			beta_history.rows(0, last_total-burnin-1) = lwbetah.rows(diff_burnin, lwiters-1);
			arma::mat lwdeltah = last_work["xi_history"];
			xi_history.rows(0, last_total-burnin-1) = lwdeltah.rows(diff_burnin, lwiters-1);
			arma::mat lwsigmah = last_work["sigma2y_history"];
			sigma2y_history.rows(0, last_total-burnin-1) = lwsigmah.rows(diff_burnin, lwiters-1);
			arma::mat lwslabm = last_work["Is_slab_matrix"];
			Is_slab_matrix.rows(0, last_total-burnin-1) = lwslabm.rows(diff_burnin, lwiters-1);
			arma::mat lwwh = last_work["w_history"];
			w_history.rows(0, last_total-burnin-1) = lwwh.rows(diff_burnin, lwiters-1);
			arma::mat lwih = last_work["intc_history"];
			intc_history.rows(0, last_total-burnin-1) = lwih.rows(diff_burnin, lwiters-1);
			arma::mat lwpsih = last_work["psi2_history"];
			psi2_history.rows(0, last_total-burnin-1) = lwpsih.rows(diff_burnin, lwiters-1);
		}
		alldraw = as<arma::vec>(last_work["alldraw"]);
		intc = as<arma::vec>(last_work["intc"]);
		num_prev_slabs = last_work["num_prev_slabs"];
		num_prev_spikes = last_work["num_prev_spikes"];
		start = last_total;
	}
	
	// start sampler
	for(int i = start; i<totaliters; ++i){
		pr.increment(); // update progress
		
		// spike & slab
		List temp = spikenslab(s_0, s_1, w_indifference, a_w, b_w, num_prev_slabs, num_prev_spikes, a_p, b_p, alldraw.subvec(lbx, alldraw.n_elem-1), psi2draw, SS_priortype);
		arma::vec dMat = temp["Var_spike_slab"];
		priorV.subvec(lbx, priorV.n_elem-1) = dMat;
		arma::mat invV = arma::diagmat(arma::pow(priorV, -1.0));
		num_prev_slabs = temp["num.slabs"];
		num_prev_spikes = temp["num.spikes"];
		psi2draw = as<arma::vec>(temp["psi2_draw"]);
		
		// sigmay^2 and alldraw
		s2ydraw = sigma2_gibbs(yst, desst, alldraw, invV, arma::eye(n,n), pis, beta_priortype);
		alldraw = beta_gibbs0(yst, desst, alldraw, invV, arma::eye(n,n), s2ydraw, beta_priortype, numBlocks);
		
		// intercept
		intc = beta_gibbs0(y - design * (alldraw % (sdy/sddes)), onesn, intc, invV.submat(0,0,0,0)*0+1e-6, arma::eye(n,n), s2ydraw*vary, beta_priortype, 1);
		
		// save draws
		arma::vec isslab = temp["Is_slab"];
		int temp00 = modulo(i, thinning);
		if ((i >= burnin) & (temp00==0)) {
			if (lbx>0){ beta_history.row((i-burnin)/thinning) = arma::trans(alldraw.subvec(0, lbx-1)); }
			xi_history.row((i-burnin)/thinning) = arma::trans(alldraw.subvec(lbx, alldraw.n_elem-1));
			sigma2y_history.row((i-burnin)/thinning) = s2ydraw;
			Is_slab_matrix.row((i-burnin)/thinning) = isslab.t();
			psi2_history.row((i-burnin)/thinning) = psi2draw.t();
			double tempw = temp["w"];
			w_history.row((i-burnin)/thinning) = tempw;
			intc_history.row((i-burnin)/thinning) = intc;
		}
	}
	
	last_work["alldraw"] = alldraw;
	last_work["intc"] = intc;
	last_work["beta_history"] = beta_history;
	last_work["sigma2y_history"] = sigma2y_history;
	last_work["xi_history"] = xi_history;
	last_work["psi2_history"] = psi2_history;
	last_work["Is_slab_matrix"] = Is_slab_matrix;
	last_work["w_history"] = w_history;
	last_work["intc_history"] = intc_history;
	last_work["iters"] = beta_history.n_rows;
	last_work["burnin"] = totaliters - beta_history.n_rows;
	last_work["num_prev_slabs"] = num_prev_slabs;
	last_work["num_prev_spikes"] = num_prev_spikes;
	
	saveRDS(last_work, wrap(filename));
	
	// results back to original scale
	arma::vec ones(std::floor(iters/thinning), arma::fill::ones);
	if (lbx>0) {
	  beta_history = beta_history * sdy / (ones * sdx);
	}
	sigma2y_history = sigma2y_history * vary;
	xi_history = xi_history * sdy / (ones * arma::stddev(B));
	psi2_history = psi2_history * vary / (ones * arma::var(B));
	
	arma::mat pmeanbeta;
	if (lbx>0) {
	  pmeanbeta = arma::mean(beta_history);
	}
	
	return List::create(Named("Postmean.beta") = pmeanbeta,
						Named("Postmean.sigma2y") = arma::mean(sigma2y_history),
						Named("Beta.draws") = beta_history,
						Named("sigma2y.draws") = sigma2y_history,
						Named("xi.draws") = xi_history,
						Named("psi.draws") = psi2_history,
						Named("Is_slab_matrix") = Is_slab_matrix,
						Named("intercept_history") = intc_history,
						Named("w.draws") = w_history);
}
