#ifndef GIBBSFUN_H
#define GIBBSFUN_H

#include <RcppArmadillo.h>
#include <math.h>


namespace gibbsupdate {

/*
Sample from full conditional of linear regression coefficients, beta
prior: beta ~ N(pmean, invV^-1)
likelihood: y|beta, sigma2 ~ N(x*beta, sigma2 * (invOmega^-1))
priortype: 1 if natural conjugate priors, 2 if independent priors
numBlocks: to update beta in blocks. If numBlocks=1 beta is updated at once
when pmean=0, use beta_gibbs0 for more efficiency
*/

arma::vec beta_gibbs0(const arma::vec& y, const arma::mat& x, arma::vec& beta, const arma::mat& invV,
								const arma::mat& invOmega, const double& sigma2, const int& priortype, const int& numBlocks = 10) {
	int p = x.n_cols;
	int jumps = floor(p/numBlocks);
	arma::uvec w;
	
	switch(priortype) {
		case 1:
		{
			for(int jj = 0; jj<numBlocks; ++jj){
				w = arma::regspace<arma::uvec>(jj*jumps, (jj+1)*jumps-1);
				if(jj == numBlocks-1){
					w = arma::regspace<arma::uvec>(jj*jumps, p-1);
				}
				
				arma::mat x_shed = x;
				x_shed.shed_cols(w);
				arma::vec beta_shed = beta;
				beta_shed.shed_rows(w);
				arma::vec tempY = y - (x_shed * beta_shed);
				arma::mat tempV = arma::inv_sympd(arma::symmatu(invV.submat(w,w) + x.cols(w).t() * invOmega * x.cols(w)));
				arma::vec tempMU = tempV * x.cols(w).t() * invOmega * tempY;
				beta.elem(w) = arma::mvnrnd(tempMU, sigma2 * tempV);
			}
			break;
		}
		case 2:
		{
			for(int jj = 0; jj<numBlocks; ++jj){
				w = arma::regspace<arma::uvec>(jj*jumps, (jj+1)*jumps-1);
				if(jj == numBlocks-1){
					w = arma::regspace<arma::uvec>(jj*jumps, p-1);
				}
				
				arma::mat x_shed = x;
				x_shed.shed_cols(w);
				arma::vec beta_shed = beta;
				beta_shed.shed_rows(w);
				arma::vec tempY = y - (x_shed * beta_shed);
				arma::mat tempV = arma::inv_sympd(arma::symmatu(invV.submat(w,w) + 1.0/sigma2 * x.cols(w).t() * invOmega * x.cols(w)));
				arma::vec tempMU = 1.0/sigma2 * tempV * x.cols(w).t() * invOmega * tempY;
				beta.elem(w) = arma::mvnrnd(tempMU, tempV);
			}
			break;
		}
		default:
			Rcpp::stop("Object 'priortype' must be either 1 (natural conjugate Normal-Gamma) or 2 (independent priors)");
			break;
	}
	
	return beta;
}





arma::vec beta_gibbs(const arma::vec& y, const arma::mat& x, arma::vec& beta, const arma::vec& pmean, const arma::mat& invV,
								const arma::mat& invOmega, const double& sigma2, const int& priortype, const int& numBlocks = 10) {
	int p = x.n_cols;
	int jumps = std::floor(p/numBlocks);
	int first, last;
	
	switch(priortype) {
		case 1:
		{
			for(int jj = 0; jj<numBlocks; ++jj){
				first = jj*jumps, last = (jj+1)*jumps-1;
				if(jj == numBlocks-1){
					last = p-1;
				}
				
				arma::mat x_shed = x;
				x_shed.shed_cols(first,last);
				arma::vec beta_shed = beta;
				beta_shed.shed_rows(first,last);
				arma::vec tempY = y - (x_shed * beta_shed);
				arma::mat tempV = arma::inv_sympd(arma::symmatu(invV.submat(first,first,last,last) + x.cols(first,last).t() * invOmega * x.cols(first,last)));
				arma::vec tempMU = tempV * (invV.submat(first,first,last,last) * pmean.subvec(first,last) + x.cols(first,last).t() * invOmega * tempY);
				beta.subvec(first,last) = arma::mvnrnd(tempMU, sigma2 * tempV);
			}
			break;
		}
		case 2:
		{
			for(int jj = 0; jj<numBlocks; ++jj){
				first = jj*jumps, last = (jj+1)*jumps-1;
				if(jj == numBlocks-1){
					last = p-1;
				}
				
				arma::mat x_shed = x;
				x_shed.shed_cols(first,last);
				arma::vec beta_shed = beta;
				beta_shed.shed_rows(first,last);
				arma::vec tempY = y - (x_shed * beta_shed);
				arma::mat tempV = arma::inv_sympd(arma::symmatu(invV.submat(first,first,last,last) + 1.0/sigma2 * x.cols(first,last).t() * invOmega * x.cols(first,last)));
				arma::vec tempMU = tempV * (invV.submat(first,first,last,last) * pmean.subvec(first,last) + 1.0/sigma2 * x.cols(first,last).t() * invOmega * tempY);
				beta.subvec(first,last) = arma::mvnrnd(tempMU, tempV);
			}
			break;
		}
		default:
			Rcpp::stop("Object 'priortype' must be either 1 (natural conjugate Normal-Gamma) or 2 (independent priors)");
			break;
	}
	
	return beta;
}



/*
Sample from full conditional of residual variance, sigma2
prior: sigma2 ~ IG(prior(0), prior(1))
*/

double sigma2_gibbs(const arma::vec& y, const arma::mat& x, arma::vec& beta, const arma::mat& invV, const arma::mat& invOmega,
					const Rcpp::NumericVector& prior, const int& priortype) {
	int n = x.n_rows, p = x.n_cols;
	double sigma2;
	
	switch(priortype) {
		case 1:
		{
			double shape = prior(0) + (n+p)/2.0;
			arma::vec e = y - x * beta;
			double rate = arma::as_scalar(prior(1) + 0.5 * (e.t() * invOmega * e) + 0.5 * beta.t() * invV * beta);
			sigma2 = 1.0/arma::randg<double>(arma::distr_param(shape,1.0/rate));
			break;
		}
		case 2:
		{
			double shape = prior(0) + n/2.0;
			arma::vec e = y - x * beta;
			double rate = arma::as_scalar(prior(1) + 0.5 * (e.t() * invOmega * e));
			sigma2 = 1.0/arma::randg<double>(arma::distr_param(shape,1.0/rate));
			break;
		}
		default:
			Rcpp::stop("Object 'priortype' must be either 1 (natural conjugate Normal-Gamma) or 2 (independent priors)");
			break;
	}
	
	return sigma2;
}



}



#endif
